import {CapacitorHttp} from '@capacitor/core';
import {App} from '@capacitor/app';
import {SplashScreen} from '@capacitor/splash-screen';
import {StatusBar,Style} from '@capacitor/status-bar';
import fallback from './default-config.json';
import {SITE,CONFIG_API,allowedImage,parseConfig,validateConfig} from './config.js';
import {native,sharePNG,savePNG,openURL,readCache,writeCache} from './native.js';
import './style.css';
const status=document.querySelector('#network'),app=document.querySelector('#app');
if(native)window.PI11Native={sharePNG,savePNG};
function script(src){return new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=reject;document.head.append(s);});}
let refreshing=false,cache=null,rendered=false,lastAttempt=0;
function branding(cfg){
  const header=document.querySelector('.app-top div');header.firstChild.textContent=cfg.brand||'PEŞİNDEYİZ';
  header.querySelector('small').textContent=cfg.heading||'İlk 11 Kur';
  document.querySelector('.app-top img').src=cfg.logo||'/assets/brand/aslan.png';
}
function render(cfg){
  const root=document.createElement('div');root.className='pi11';root.dataset.pi11='';
  const data=document.createElement('script');data.type='application/json';data.className='pi11-config';data.textContent=JSON.stringify(cfg);
  const mount=document.createElement('div');mount.className='pi11-mount';root.append(data,mount);app.replaceChildren(root);
  return script('/assets/app.js').then(()=>{rendered=true;branding(cfg);if(native)root.querySelector('[data-action="download"]').textContent='Galeriye kaydet';});
}
async function picture(url,oldImages,revision){
  if(!allowedImage(url))return '';
  if(oldImages[url])return oldImages[url];
  if(!native)return ''; // Browser preview intentionally uses bundled images without CORS.
  try{
    const request=new URL(url);request.searchParams.set('pi11_rev',revision);
    const r=await CapacitorHttp.get({url:request.href,responseType:'arraybuffer',connectTimeout:8000,readTimeout:12000});
    const type=String(Object.entries(r.headers||{}).find(([key])=>key.toLowerCase()==='content-type')?.[1]||'').split(';')[0];
    if(r.status!==200||!/^image\/(png|jpeg|webp)$/.test(type)||typeof r.data!=='string'||r.data.length>6000000)return '';
    return 'data:'+type+';base64,'+r.data;
  }catch{return '';}
}
async function get(url,kind){
  const u=new URL(url);u.searchParams.set('_pi11',Date.now());
  if(native){const r=await CapacitorHttp.get({url:u.href,responseType:kind,connectTimeout:8000,readTimeout:12000,headers:{'Cache-Control':'no-cache'}});if(r.status!==200)throw new Error();return r.data;}
  const r=await fetch(u.href,{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!r.ok)throw new Error();return kind==='json'?r.json():r.text();
}
async function refresh(){
  if(refreshing)return;refreshing=true;lastAttempt=Date.now();document.querySelector('#refresh').disabled=true;
  status.textContent='Güncelleniyor…';
  try{
    let cfg;
    try{const raw=await get(CONFIG_API,'json');cfg=validateConfig(typeof raw==='string'?JSON.parse(raw):raw);}
    catch{cfg=parseConfig(await get(SITE,'text'));}
    const revision=cfg.revision||String([...JSON.stringify(cfg)].reduce((hash,c)=>Math.imul(hash^c.charCodeAt(0),16777619)>>>0,2166136261));
    if(revision===cache?.revision){status.textContent='Güncellendi.';return;}
    const images={},previous=cache?.revision===revision?cache.images:{};
    const urls=[...new Set([...Object.values(cfg.photos),cfg.logo,cfg.footerLogo,cfg.background].filter(Boolean))];
    let cursor=0;
    await Promise.all(Array.from({length:4},async()=>{while(cursor<urls.length){const url=urls[cursor++];const value=await picture(url,previous,String(revision).slice(0,80))||cache?.images?.[url];if(value)images[url]=value;}}));
    for(const name of Object.keys(cfg.photos)){const url=cfg.photos[name];cfg.photos[name]=images[url]||fallback.photos[name]||'';}
    for(const key of ['logo','footerLogo','background'])cfg[key]=images[cfg[key]]||fallback[key]||'';
    cache={config:cfg,images,revision,updated:Date.now()};await writeCache(cache);
    const root=app.querySelector('[data-pi11]');
    if(rendered&&root?.pi11UpdateConfig){root.pi11UpdateConfig(cfg);branding(cfg);}else await render(cfg);
    status.textContent='Güncellendi.';
  }catch{status.textContent='Çevrimdışı kadro kullanılıyor. İnternet geldiğinde Yenile’ye dokun.';}
  finally{refreshing=false;document.querySelector('#refresh').disabled=false;}
}
async function start(){
  try{
    cache=await readCache();await script('/assets/formations.js');await render(cache?.config||fallback);
    if(native){await StatusBar.setStyle({style:Style.Dark}).catch(()=>{});await SplashScreen.hide().catch(()=>{});}
    document.querySelector('#launch').remove();
    status.textContent=cache?'Son kaydedilen kadro açıldı.':'Kayıtlı başlangıç kadrosu açıldı.';
    void refresh();
  }catch{document.querySelector('#launch').innerHTML='<strong>Uygulama açılamadı.</strong><button onclick="location.reload()">Tekrar dene</button>';if(native)void SplashScreen.hide();}
}
document.querySelector('#refresh').addEventListener('click',refresh);
window.addEventListener('online',()=>void refresh());
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&Date.now()-lastAttempt>15000)void refresh();});
document.querySelector('#website').addEventListener('click',()=>openURL(SITE));
const about=document.querySelector('#about-dialog');
document.querySelector('#about').addEventListener('click',()=>about.showModal());document.querySelector('#about-close').addEventListener('click',()=>about.close());
document.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(a&&/^https?:/.test(a.href)){e.preventDefault();void openURL(a.href);}});
if(native){
  App.addListener('appStateChange',({isActive})=>{if(isActive&&Date.now()-lastAttempt>15000)void refresh();});
  App.addListener('backButton',()=>{const d=[...document.querySelectorAll('dialog[open]')].at(-1);if(d){d.dispatchEvent(new Event('cancel',{cancelable:true}));if(d.open)d.close();}else App.minimizeApp();});
}
void start();
