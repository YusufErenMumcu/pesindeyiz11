export const CONFIG_API='https://pesindeyiz.com/wp-json/pesindeyiz-ilk11/v1/config';
export const SITE='https://pesindeyiz.com/gs11/';
export function allowedImage(url){
  try{const u=new URL(url);return u.protocol==='https:'&&['pesindeyiz.com','www.pesindeyiz.com'].includes(u.hostname)&&!u.username&&!u.password;}catch{return false;}
}
export function parseConfig(html,DOMParserClass=DOMParser){
  const doc=new DOMParserClass().parseFromString(html,'text/html');
  const node=doc.querySelector('script.pi11-config');if(!node)throw new Error('Kadro verisi bulunamadı.');
  return validateConfig(JSON.parse(node.textContent));
}
export function validateConfig(input){
  const cfg=structuredClone(input);
  if(!Array.isArray(cfg.roster)||!cfg.roster.length||cfg.roster.length>200)throw new Error('Oyuncu listesi geçersiz.');
  cfg.roster=cfg.roster.filter(p=>typeof p.name==='string'&&p.name.trim()).map(p=>({id:String(p.id||p.name).slice(0,100),name:p.name.slice(0,40),number:/^\d{1,2}$/.test(String(p.number))?String(p.number):'',position:String(p.position||'Oyuncu').slice(0,80)}));
  if(!cfg.roster.length)throw new Error('Oyuncu listesi boş.');
  cfg.extraPlayers=[];cfg.siteUrl='https://pesindeyiz.com/';
  cfg.photos=Object.fromEntries(Object.entries(cfg.photos||{}).filter(([name,url])=>typeof name==='string'&&allowedImage(url)).slice(0,200));
  for(const key of ['background','logo','footerLogo'])if(!allowedImage(cfg[key]))cfg[key]='';
  for(const key of ['brand','heading','tagline','defaultTitle'])cfg[key]=String(cfg[key]||'').slice(0,100);
  for(const key of ['primary','secondary'])if(!/^#[a-f0-9]{6}$/i.test(cfg[key]||''))delete cfg[key];
  return cfg;
}
