import {Capacitor,registerPlugin} from '@capacitor/core';
import {Filesystem,Directory,Encoding} from '@capacitor/filesystem';
import {Share} from '@capacitor/share';
import {Browser} from '@capacitor/browser';
import {Media} from '@capacitor-community/media';
const AndroidGallery=registerPlugin('LineupGallery');
export const native=Capacitor.isNativePlatform();
let sequence=0;
async function writePNG(blob){
  const base64=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=reject;r.readAsDataURL(blob);});
  // Only the cache directory is shared; no broad storage permission is needed.
  const path='lineup-share-'+(sequence++%5)+'.png';
  return (await Filesystem.writeFile({path,data:base64,directory:Directory.Cache})).uri;
}
export async function sharePNG(blob,text,title){
  if(!native)throw new Error('Native paylaşım bu önizlemede kullanılamaz.');
  const uri=await writePNG(blob);
  try{await Share.share({title,text,files:[uri],dialogTitle:'Kadronu paylaş'});}
  catch(e){if(/cancel|dismiss/i.test(String(e?.message||e)))throw new DOMException('İptal edildi','AbortError');throw e;}
}
export async function savePNG(blob){
  const uri=await writePNG(blob);
  if(Capacitor.getPlatform()==='android')return AndroidGallery.saveImage({path:uri});
  if(Capacitor.getPlatform()==='ios')return Media.savePhoto({path:uri});
  throw new Error('Galeriye kaydetme telefondaki uygulamada kullanılabilir.');
}
export async function openURL(url){
  const u=new URL(url);if(!['https:','http:'].includes(u.protocol))return;
  if(native)await Browser.open({url:u.href});else window.open(u.href,'_blank','noopener,noreferrer');
}
export async function readCache(){
  try{if(native){const r=await Filesystem.readFile({path:'lineup-cache.json',directory:Directory.Data,encoding:Encoding.UTF8});return JSON.parse(String(r.data));}
    return JSON.parse(localStorage.getItem('pi11-mobile-config'));}catch{return null;}
}
export async function writeCache(value){
  try{const data=JSON.stringify(value);if(native)await Filesystem.writeFile({path:'lineup-cache.json',directory:Directory.Data,data,encoding:Encoding.UTF8});
    else localStorage.setItem('pi11-mobile-config',data);}catch{}
}
