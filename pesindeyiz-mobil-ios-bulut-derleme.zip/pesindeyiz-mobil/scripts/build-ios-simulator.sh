#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
if [ "$(uname -s)" != "Darwin" ]; then
  echo "iOS derlemesi macOS ve Xcode üzerinde çalıştırılmalıdır."
  exit 1
fi
npm ci
npm run sync
xcodebuild -project ios/App/App.xcodeproj -scheme App -sdk iphonesimulator -configuration Debug -derivedDataPath build/ios-simulator CODE_SIGNING_ALLOWED=NO build
echo "Simülatör uygulaması: build/ios-simulator/Build/Products/Debug-iphonesimulator/App.app"
