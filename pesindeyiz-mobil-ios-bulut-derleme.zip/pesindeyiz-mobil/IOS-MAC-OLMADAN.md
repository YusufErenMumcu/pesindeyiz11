# Mac olmadan iPhone sürümü

Mac yoksa derleme GitHub'ın ücretsiz macOS sunucusunda yapılır.

## 1. IPA'yı bulutta derle

1. github.com'da ücretsiz hesap açın, yeni **private** bir depo oluşturun.
2. Bu klasörün içeriğini depoya yükleyin (`.github` klasörü dahil).
3. Depoda **Actions → iOS IPA (imzasız) → Run workflow** deyin.
4. Birkaç dakika sonra iş bitince sayfanın altındaki **Artifacts** bölümünden
   `Pesindeyiz-Ilk11-unsigned-ipa` dosyasını indirin, ZIP'i açın.

Çıkan `Pesindeyiz-Ilk11-unsigned.ipa` imzasızdır; telefona doğrudan kurulmaz.

## 2. iPhone'a kur

**Ücretsiz yol (kendi telefonunuz):** Windows/Mac'te Sideloadly veya AltStore kurun,
iPhone'u kabloyla bağlayın, IPA'yı sürükleyip kendi Apple ID'nizle imzalatın.
Ücretsiz Apple ID ile imza 7 günde dolar, yenilemek gerekir.

**Kalıcı yol (başkalarına dağıtım):** Ücretli Apple Developer hesabı (yıllık 99 USD)
ile imzalı derleme alıp TestFlight veya App Store'a yüklenir. Bunun için
sertifika ve provisioning profile gerekir; Codemagic gibi bir bulut servisi
bu adımları Mac olmadan yönetebilir.
