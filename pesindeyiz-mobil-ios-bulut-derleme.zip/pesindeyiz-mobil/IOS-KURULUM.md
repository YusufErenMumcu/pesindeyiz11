# iPhone sürümü — 1.1.0

Bu pakette iOS uygulamasının Xcode projesi bulunur; imzalı IPA/TestFlight sürümü değildir.
Mevcut Linux ortamında iOS derlenemedi. Android sürümü derlenip imzası doğrulandı.

## Mac üzerinde

1. Xcode 26+ ve Node 22+ kurun.
2. Proje klasöründe npm ci ve npm run sync çalıştırın.
3. npm run ios komutuyla Xcode projesini açın.
4. Signing & Capabilities bölümünde kendi Apple Team hesabınızı seçin.
5. Bağlı iPhone veya simülatörde Run kullanın.

Simülatör için imza istemeyen otomatik derleme komutu:

    sh scripts/build-ios-simulator.sh

Gerçek cihaz/TestFlight dağıtımı için Xcode Archive ve kendi imzalama ayarlarınız gerekir.
Burada Apple hesabı, parola, sertifika veya provisioning profile bulunmaz.

## Fotoğraflar’a kaydetme

“Galeriye kaydet” doğrudan Fotoğraflar’a ekler. İlk kullanımda fotoğraf ekleme izni
istenebilir. Uygulama albümleri okumaz ve tüm fotoğraf kitaplığınıza erişim istemez.
İzin reddedilirse uygulama hata mesajı gösterir; Ayarlar’dan fotoğraf ekleme izni
verildikten sonra tekrar kaydedilebilir. SPM Media bağımlılığı ve
NSPhotoLibraryAddUsageDescription projeye eklenmiştir.

Hücum yönü yukarı sabittir. Instagram ve Twitter/X takip bağlantıları alt bölümde bulunur.
Oyuncular ve görünüm ayarları mevcut WordPress İlk 11 Kur! panelinden alınır.
