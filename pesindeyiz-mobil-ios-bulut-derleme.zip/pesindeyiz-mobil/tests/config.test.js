import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {JSDOM} from 'jsdom';
import {allowedImage,parseConfig,validateConfig} from '../src/config.js';
const Parser=new JSDOM('').window.DOMParser;
const wrap=c=>'<script type="application/json" class="pi11-config">'+JSON.stringify(c)+'</script>';
test('live WordPress snapshot imports all 38 players',()=>{
  const cfg=JSON.parse(fs.readFileSync('src/default-config.json','utf8'));
  const parsed=parseConfig(wrap({...cfg,photos:{'Oyuncu':'https://pesindeyiz.com/photo.png'}}),Parser);
  assert.equal(parsed.roster.length,38);assert.equal(parsed.siteUrl,'https://pesindeyiz.com/');
  assert.equal(parsed.photos.Oyuncu,'https://pesindeyiz.com/photo.png');
  const direct=validateConfig({...cfg,revision:'server-2'});
  assert.equal(direct.revision,'server-2');
  assert.equal(direct.roster[0].name,cfg.roster[0].name);
});
test('external markup is data only; invalid rosters and image origins rejected',()=>{
  assert.throws(()=>parseConfig('<html></html>',Parser));
  assert.throws(()=>parseConfig(wrap({roster:[]}),Parser));
  assert(allowedImage('https://pesindeyiz.com/wp-content/photo.png'));
  for(const url of ['javascript:alert(1)','https://evil.com/a.png','https://pesindeyiz.com.evil.com/a.png','http://pesindeyiz.com/a.png','https://a:b@pesindeyiz.com/a.png'])assert(!allowedImage(url));
  const c=parseConfig(wrap({roster:[{name:'Test',number:'999'}],photos:{Test:'https://evil.com/a.png'},primary:'red'}),Parser);
  assert.equal(c.roster[0].number,'');assert.deepEqual(c.photos,{});assert.equal(c.primary,undefined);
});
test('offline package has all referenced fallback assets',()=>{
  const cfg=JSON.parse(fs.readFileSync('src/default-config.json','utf8'));
  for(const path of [...Object.values(cfg.photos),cfg.logo,cfg.footerLogo])assert(fs.existsSync('public'+path),path);
  const context={};new Function('window',fs.readFileSync('public/assets/formations.js','utf8'))(context);
  assert.equal(Object.keys(context.PI11Tactics.templates).length,22);
  for(const f of Object.keys(context.PI11Tactics.templates))assert.equal(context.PI11Tactics.points(f).length,11);
});
test('native sharing bridge is used by the actual lineup engine',()=>{
  const app=fs.readFileSync('public/assets/app.js','utf8');
  assert(app.includes('window.PI11Native.sharePNG(await pngBlob(),shareText()'));
  assert(app.includes('window.PI11Native.savePNG(blob)'));
  assert(!JSON.parse(fs.readFileSync('capacitor.config.json')).server,'No remote web code container');
});
