import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {JSDOM} from 'jsdom';
test('social follow profiles and simplified refresh labels',()=>{
  const d=new JSDOM(fs.readFileSync('index.html','utf8')).window.document;
  assert.equal(d.querySelector('.follow-links a').href,'https://www.instagram.com/pesindeyizcom/');
  assert.equal(d.querySelectorAll('.follow-links a')[1].href,'https://x.com/PesindeyizApp');
  const main=fs.readFileSync('src/main.js','utf8');
  assert(main.includes("status.textContent='Güncelleniyor…'"));
  assert(main.includes("status.textContent='Güncellendi.'"));
  assert(!/status.textContent='[^']*WordPress/.test(main));
});
test('direct gallery APIs and native permissions are present in both platforms',()=>{
  const native=fs.readFileSync('src/native.js','utf8');
  assert(native.includes('AndroidGallery.saveImage({path:uri})'));
  assert(native.includes('Media.savePhoto({path:uri})'));
  const save=native.split('export async function savePNG(blob){')[1].split('export async function openURL')[0];
  assert(!save.includes('Share.share'),'Save must not open the sharing sheet');
  const ios=fs.readFileSync('ios/App/App/Info.plist','utf8');assert(ios.includes('NSPhotoLibraryAddUsageDescription'));
  const java=fs.readFileSync('android/app/src/main/java/com/pesindeyiz/ilk11/LineupGalleryPlugin.java','utf8');
  assert(java.includes('MediaStore.Images.Media.RELATIVE_PATH'));
  assert(java.includes('MediaScannerConnection.scanFile'));
  assert(java.includes('getCacheDir().getCanonicalPath()'));
  assert(fs.readFileSync('android/app/src/main/AndroidManifest.xml','utf8').includes('android:maxSdkVersion="28"'));
});
