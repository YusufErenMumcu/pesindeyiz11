package com.pesindeyiz.ilk11;

import com.getcapacitor.BridgeActivity;
import android.os.Bundle;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(LineupGalleryPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
