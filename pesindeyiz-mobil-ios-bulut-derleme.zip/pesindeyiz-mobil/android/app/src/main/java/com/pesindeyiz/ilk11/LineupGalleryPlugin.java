package com.pesindeyiz.ilk11;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

@CapacitorPlugin(name="LineupGallery", permissions={
    @Permission(alias="legacyGallery",strings={Manifest.permission.WRITE_EXTERNAL_STORAGE})
})
public class LineupGalleryPlugin extends Plugin {
    @PluginMethod public void saveImage(PluginCall call) {
        if (Build.VERSION.SDK_INT < 29 && getPermissionState("legacyGallery") != PermissionState.GRANTED) {
            requestPermissionForAlias("legacyGallery",call,"galleryPermission");
        } else save(call);
    }
    @PermissionCallback private void galleryPermission(PluginCall call) {
        if (getPermissionState("legacyGallery") == PermissionState.GRANTED) save(call);
        else call.reject("Galeriye kaydetme izni verilmedi.","accessDenied");
    }
    private void copy(File source,OutputStream out) throws Exception {
        if (out==null) throw new Exception("Galeri dosyası açılamadı.");
        try(InputStream in=new FileInputStream(source)) {
            byte[] buffer=new byte[8192];int n;
            while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
        }
    }
    private void save(PluginCall call) {
        Uri created=null;File legacyFile=null;
        ContentResolver resolver=getContext().getContentResolver();
        try {
            String path=call.getString("path");
            if(path==null)throw new Exception("Görsel bulunamadı.");
            Uri uri=Uri.parse(path);
            if(!"file".equals(uri.getScheme()) || uri.getPath()==null)throw new Exception("Görsel yolu geçersiz.");
            File source=new File(uri.getPath()).getCanonicalFile();
            String cache=getContext().getCacheDir().getCanonicalPath()+File.separator;
            if(!source.getPath().startsWith(cache)||!source.isFile()||source.length()<8||source.length()>20L*1024*1024)
                throw new Exception("Kaydedilecek görsel geçersiz.");
            try(InputStream check=new FileInputStream(source)){
                byte[] png={(byte)137,80,78,71,13,10,26,10};
                for(byte value:png)if(check.read()!=(value&255))throw new Exception("PNG görseli gerekli.");
            }
            String name="pesindeyiz-ilk11-"+System.currentTimeMillis()+".png";
            if(Build.VERSION.SDK_INT>=29) {
                ContentValues values=new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME,name);
                values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/Pesindeyiz");
                values.put(MediaStore.Images.Media.IS_PENDING,1);
                created=resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
                if(created==null)throw new Exception("Galeri kaydı oluşturulamadı.");
                try(OutputStream out=resolver.openOutputStream(created)){copy(source,out);}
                ContentValues ready=new ContentValues();ready.put(MediaStore.Images.Media.IS_PENDING,0);
                resolver.update(created,ready,null,null);
                JSObject result=new JSObject();result.put("uri",created.toString());call.resolve(result);
            } else {
                File folder=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"Pesindeyiz");
                if(!folder.isDirectory()&&!folder.mkdirs())throw new Exception("Galeri klasörü oluşturulamadı.");
                legacyFile=new File(folder,name);
                try(OutputStream out=new FileOutputStream(legacyFile)){copy(source,out);}
                final File saved=legacyFile;
                MediaScannerConnection.scanFile(getContext(),new String[]{saved.getAbsolutePath()},new String[]{"image/png"},(file,mediaUri)->{
                    JSObject result=new JSObject();result.put("uri",mediaUri!=null?mediaUri.toString():Uri.fromFile(saved).toString());call.resolve(result);
                });
            }
        } catch(Exception e) {
            if(created!=null)resolver.delete(created,null,null);
            if(legacyFile!=null)legacyFile.delete();
            call.reject("Galeriye kaydedilemedi: "+e.getMessage(),"galleryError",e);
        }
    }
}
