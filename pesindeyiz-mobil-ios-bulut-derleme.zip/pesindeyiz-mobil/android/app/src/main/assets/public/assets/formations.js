/* Tactical templates: u is pitch width, v is distance from our goalkeeper.
 * Each role has its own depth. The projected pitch narrows toward the far goal.
 * Quicklineup's public diagrams informed the spacing; this is independent code.
 */
(() => {
  'use strict';
  const roleNames={GK:'Kaleci',LB:'Sol bek',LCB:'Sol stoper',CB:'Stoper',RCB:'Sağ stoper',RB:'Sağ bek',LWB:'Sol kanat bek',RWB:'Sağ kanat bek',DM:'Ön libero',LDM:'Sol ön libero',RDM:'Sağ ön libero',LCM:'Sol merkez',CM:'Merkez orta saha',RCM:'Sağ merkez',LM:'Sol orta saha',RM:'Sağ orta saha',AM:'On numara',LAM:'Sol on numara',RAM:'Sağ on numara',LW:'Sol kanat',RW:'Sağ kanat',SS:'İkinci forvet',LST:'Sol forvet',RST:'Sağ forvet',ST:'Santrafor'};
  const S=(role,u,v)=>({role,u,v});
  const g=()=>S('GK',.5,.05);
  const d4=()=>[S('LB',.13,.27),S('LCB',.36,.25),S('RCB',.64,.25),S('RB',.87,.27)];
  const d3=()=>[S('LCB',.26,.25),S('CB',.5,.25),S('RCB',.74,.25)];
  const d5=()=>[S('LWB',.10,.37),S('LCB',.29,.25),S('CB',.5,.25),S('RCB',.71,.25),S('RWB',.90,.37)];
  const pair=(v,roles=['LDM','RDM'])=>[S(roles[0],.35,v),S(roles[1],.65,v)];
  const mid3=v=>[S('LCM',.28,v),S('CM',.5,v),S('RCM',.72,v)];
  const mid4=v=>[S('LM',.12,v+.035),S('LCM',.36,v),S('RCM',.64,v),S('RM',.88,v+.035)];
  const front2=v=>[S('LST',.32,v),S('RST',.68,v)];
  const front3=v=>[S('LW',.20,v-.035),S('ST',.5,v),S('RW',.80,v-.035)];
  const wingbacks=v=>[S('LWB',.10,v),S('RWB',.90,v)];
  const T={
    '4-4-2':[g(),...d4(),...mid4(.49),...front2(.78)],
    '3-1-4-2':[g(),...d3(),S('DM',.5,.45),S('LM',.1,.55),S('LCM',.32,.62),S('RCM',.68,.62),S('RM',.9,.55),...front2(.85)],
    '3-4-2-1':[g(),...d3(),...wingbacks(.49),...pair(.47),...pair(.68,['LAM','RAM']),S('ST',.5,.87)],
    '3-4-1-2':[g(),...d3(),...wingbacks(.47),...pair(.44,['LCM','RCM']),S('AM',.5,.64),...front2(.85)],
    '3-4-3':[g(),...d3(),...wingbacks(.48),...pair(.48,['LCM','RCM']),...front3(.81)],
    '3-5-1-1':[g(),...d3(),...wingbacks(.45),S('LCM',.28,.54),S('DM',.5,.44),S('RCM',.72,.54),S('SS',.5,.69),S('ST',.5,.88)],
    '3-5-2':[g(),...d3(),...wingbacks(.43),...mid3(.57),...front2(.83)],
    '3-5-2-B':[g(),...d3(),...wingbacks(.51),S('DM',.5,.45),S('LCM',.31,.61),S('RCM',.69,.61),...front2(.85)],
    '4-1-4-1':[g(),...d4(),S('DM',.5,.46),...mid4(.65),S('ST',.5,.86)],
    '4-1-2-1-2':[g(),...d4(),S('DM',.5,.45),S('LCM',.33,.59),S('RCM',.67,.59),S('AM',.5,.72),...front2(.88)],
    '4-1-3-2':[g(),...d4(),S('DM',.5,.45),S('LM',.15,.64),S('CM',.5,.64),S('RM',.85,.64),...front2(.87)],
    '4-2-1-3':[g(),...d4(),...pair(.46),S('AM',.5,.65),...front3(.87)],
    '4-2-2-2':[g(),...d4(),...pair(.46),...pair(.65,['LAM','RAM']),...front2(.87)],
    '4-2-3-1':[g(),...d4(),...pair(.46),S('LW',.15,.68),S('AM',.5,.68),S('RW',.85,.68),S('ST',.5,.88)],
    '4-3-1-2':[g(),...d4(),...mid3(.48),S('AM',.5,.68),...front2(.87)],
    '4-3-2-1':[g(),...d4(),...mid3(.46),...pair(.67,['LAM','RAM']),S('ST',.5,.88)],
    '4-3-3':[g(),...d4(),...mid3(.51),...front3(.82)],
    '4-4-1-1':[g(),...d4(),...mid4(.48),S('SS',.5,.68),S('ST',.5,.87)],
    '4-5-1':[g(),...d4(),S('LM',.10,.47),...mid3(.59),S('RM',.90,.47),S('ST',.5,.85)],
    '5-2-3':[g(),...d5(),...pair(.55,['LCM','RCM']),...front3(.84)],
    '5-3-2':[g(),...d5(),...mid3(.56),...front2(.84)],
    '5-4-1':[g(),...d5(),...mid4(.60),S('ST',.5,.85)]
  };
  function points(f,direction='down',perspective=true){
    return T[f].map(p=>{
      const depth=direction==='up'?1-p.v:p.v;
      const halfWidth=perspective?.32+.115*depth:.43;
      return {x:.5+(p.u-.5)*2*halfWidth,y:.22+.66*depth};
    });
  }
  function family(role){if(role==='GK')return 'gk';if(['LB','RB','LCB','CB','RCB'].includes(role))return 'def';if(['LW','RW','SS','LST','RST','ST'].includes(role))return 'att';return 'mid';}
  function idealWidth(role){if(['LB','LWB','LM','LW'].includes(role))return .15;if(['RB','RWB','RM','RW'].includes(role))return .85;if(role==='LCB')return .30;if(role==='RCB')return .70;if(['LDM','LCM','LAM','LST'].includes(role))return .35;if(['RDM','RCM','RAM','RST'].includes(role))return .65;return .5;}
  function compatibility(a,b){
    if(a===b)return 0;
    if(['LDM','RDM'].includes(a)&&b==='DM')return 1;
    if(a==='DM'&&['LDM','RDM'].includes(b))return 4;
    if(['ST','LST','RST'].includes(a)&&!['ST','LST','RST'].includes(b))return 180;
    if([['LB','LWB'],['RB','RWB'],['LM','LW'],['RM','RW'],['LCM','LDM'],['RCM','RDM'],['AM','SS']].some(pair=>pair.includes(a)&&pair.includes(b)))return 5;
    return family(a)===family(b)?12:70;
  }
  function remap(players,oldF,newF){
    const old=T[oldF],next=T[newF],n=11,dp=new Array(1<<n).fill(Infinity),parent=new Array(1<<n);dp[0]=0;
    const pop=x=>{let k=0;while(x){x&=x-1;k++;}return k;};
    for(let mask=0;mask<(1<<n);mask++){
      const i=pop(mask);if(i>=n||!Number.isFinite(dp[mask]))continue;
      for(let j=0;j<n;j++)if(!(mask&(1<<j))){
        const a=old[i],b=next[j],preferred=players[i]?.preferredRole&&roleNames[players[i].preferredRole]?players[i].preferredRole:a.role;
        let cost=players[i]?compatibility(preferred,b.role):0;
        if((a.role==='GK')!==(b.role==='GK'))cost+=10000;
        cost+=Math.abs((players[i]?idealWidth(preferred):a.u)-b.u)*22+Math.abs(a.v-b.v)*3;
        const m=mask|(1<<j);if(dp[mask]+cost<dp[m]){dp[m]=dp[mask]+cost;parent[m]={mask,j,i};}
      }
    }
    const result=Array(n).fill(null);let mask=(1<<n)-1;
    while(mask){const p=parent[mask];result[p.j]=players[p.i];mask=p.mask;}
    return result;
  }
  window.PI11Tactics={templates:T,roleNames,points,remap};
})();
