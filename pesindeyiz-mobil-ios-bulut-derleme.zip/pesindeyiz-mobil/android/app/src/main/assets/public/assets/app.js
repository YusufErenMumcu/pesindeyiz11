/* Peşindeyiz İlk 11 — no remote scripts, no account required. */
(() => {
  'use strict';
  const formations=['4-4-2','3-1-4-2','3-4-2-1','3-4-1-2','3-4-3','3-5-1-1','3-5-2','3-5-2-B','4-1-4-1','4-1-2-1-2','4-1-3-2','4-2-1-3','4-2-2-2','4-2-3-1','4-3-1-2','4-3-2-1','4-3-3','4-4-1-1','4-5-1','5-2-3','5-3-2','5-4-1'];
  const clone = x => JSON.parse(JSON.stringify(x));
  const fold = s => String(s).toLocaleLowerCase('tr').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ı/g,'i');
  const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const labels={'Uğurcan Çakır':'UĞURCAN','Davinson Sánchez':'SÁNCHEZ','Abdülkerim Bardakcı':'ABDÜLKERİM','Ismail Jakobs':'JAKOBS','Roland Sallai':'SALLAI','Lucas Torreira':'TORREIRA','Gabriel Sara':'SARA','Yunus Akgün':'YUNUS','Leroy Sané':'SANÉ','Rafael Leão':'LEÃO','Barış Alper Yılmaz':'BARIŞ ALPER','İlkay Gündoğan':'İLKAY'};
  const tactics=window.PI11Tactics;
  const positions=(f,d='down',view='perspective')=>tactics.points(f,d,view==='perspective');
  document.querySelectorAll('[data-pi11]').forEach((root,instance) => {
    if(root.dataset.ready) return; root.dataset.ready='1';
    let cfg;try{cfg=JSON.parse(root.querySelector('.pi11-config').textContent);}catch(e){return;}
    const roster=[...(cfg.roster||[]),...(cfg.extraPlayers||[]).filter(p=>!(cfg.roster||[]).some(r=>fold(r.name)===fold(p.name)))];
    const photoURLs=new Map(Object.entries(cfg.photos||{}).map(([name,url])=>[fold(name),url]));
    const mount=root.querySelector('.pi11-mount');
    const uid='pi11-'+instance;
    mount.innerHTML=`<header class="pi11-header"><div><div class="pi11-brand">${cfg.logo?'<img class="pi11-brand-logo" src="'+esc(cfg.logo)+'" alt="Peşindeyiz aslan logosu">':''}${esc(cfg.brand||'PEŞİNDEYİZ')}</div><h2>${esc(cfg.heading??'İLK 11 KUR!')}</h2></div><span class="pi11-badge">${esc(cfg.tagline??'Senin takımın, senin kararın')}</span></header>
    <div class="pi11-layout"><div><div class="pi11-board"><canvas class="pi11-canvas" width="1080" height="1080" aria-label="İlk 11 sahası"></canvas><div class="pi11-slots"></div></div><p class="pi11-help">Oyuncu eklemek için + işaretine dokun. Yerini değiştirmek için sürükle.</p><div class="pi11-actions"><button class="pi11-primary" data-action="download">PNG indir</button><button data-action="undo" aria-label="Son değişikliği geri al">Geri al</button><button data-action="redo" aria-label="Değişikliği yinele">Yinele</button><button data-action="clear">Kadroyu temizle</button><button data-action="restart">Baştan başla</button></div><div class="pi11-share-actions" aria-label="Kadronu paylaş"><button data-action="share-x">X’te paylaş</button><button data-action="share-instagram">Instagram’da paylaş</button><button data-action="share-whatsapp">WhatsApp’ta paylaş</button></div><p class="pi11-status" role="status" aria-live="polite"></p></div>
    <aside class="pi11-controls"><h3 class="pi11-wide">Kadro ayarları</h3><label class="pi11-field"><span>Formasyon</span><select data-field="formation">${formations.map(f=>`<option>${f}</option>`).join('')}</select></label>
    <div class="pi11-tactic-preview pi11-wide" aria-label="Seçili formasyon önizlemesi"></div><p class="pi11-formation-note pi11-wide"></p>
    <label class="pi11-field"><span>Arka plan</span><select data-field="theme"><option value="brand">Peşindeyiz</option><option value="green">Yeşil</option><option value="blue">Mavi</option><option value="white">Beyaz</option>${cfg.background?'<option value="custom">Canva arka planımız</option>':''}</select></label>
    <label class="pi11-field"><span>Oyuncu görünümü</span><select data-field="display"><option value="photo">Fotoğraf</option><option value="shirt">Forma</option><option value="circle">Daire</option></select></label>
    <label class="pi11-field"><span>Saha görünümü</span><select data-field="view"><option value="perspective">Perspektif</option><option value="flat">Üstten görünüm</option></select></label>
    <label class="pi11-field"><span>Forma / çerçeve</span><input type="color" data-field="primary" value="#efbc35"></label><label class="pi11-field"><span>İkinci renk</span><input type="color" data-field="secondary" value="#b32031"></label>
    <button class="pi11-wide" data-action="reset-colors">Renkleri sıfırla</button><label class="pi11-field pi11-wide"><span>Kadro başlığı</span><input data-field="title" maxlength="45" value="BENİM İLK 11’İM"></label>
    <label class="pi11-check pi11-wide"><input data-field="lines" type="checkbox" checked>Saha çizgileri</label><label class="pi11-check pi11-wide"><input data-field="numbers" type="checkbox" checked>Forma numaraları</label>
    <div class="pi11-rule pi11-wide"></div><h3 class="pi11-wide">Seçili oyuncu</h3><p class="pi11-current pi11-wide">Bir saha konumu seç.</p><div class="pi11-actions pi11-wide"><button class="pi11-gold" data-action="edit">Oyuncu seç / düzenle</button><button data-action="transfer">Transfer lazım</button><button data-action="remove">Kaldır</button></div>
    <div class="pi11-rule pi11-wide"></div><h3 class="pi11-wide">Yerleşim</h3><label class="pi11-field"><span>Yatay konum</span><input type="range" min="10" max="90" step="1" data-field="x" value="50"></label><label class="pi11-field"><span>Dikey konum</span><input type="range" min="25" max="85" step="1" data-field="y" value="85"></label><button class="pi11-wide" data-action="align">Formasyona hizala</button>
    <p class="pi11-current pi11-wide">Kadro bu tarayıcıda otomatik saklanır.</p></aside></div>
    <dialog class="pi11-dialog" aria-labelledby="${uid}-dialog-title"><div class="pi11-dialog-head"><button class="pi11-close" aria-label="Oyuncu seçimini kapat">✕</button><h3 id="${uid}-dialog-title">Oyuncu seç</h3><input class="pi11-search" placeholder="İsim veya forma numarası ara" aria-label="Oyuncu ara"></div><div class="pi11-player-list"></div><div class="pi11-dialog-footer"><button class="pi11-gold" data-choice="transfer">Transfer lazım</button><label for="${uid}-name">Özel oyuncu / transfer hedefi</label><div class="pi11-custom"><input id="${uid}-name" class="pi11-custom-name" maxlength="40" placeholder="Oyuncu adı"><input class="pi11-custom-number" type="number" min="0" max="99" placeholder="No" aria-label="Özel oyuncu forma numarası"></div><label class="pi11-photo-upload">Özel fotoğraf<input class="pi11-photo-file" type="file" accept="image/png,image/jpeg,image/webp"></label><small class="pi11-photo-note"></small><button data-choice="photo-clear">Özel fotoğrafı kaldır</button><button class="pi11-primary" data-choice="custom">Bu oyuncuyu ekle</button><button data-choice="remove">Bu konumu boşalt</button><p class="pi11-dialog-error" role="alert"></p></div></dialog>`;
    const $=s=>mount.querySelector(s), canvas=$('canvas'),ctx=canvas.getContext('2d'),slots=$('.pi11-slots'),dialog=$('dialog');
    const base=()=>({layoutVersion:2,formation:formations.includes(cfg.formation)?cfg.formation:'4-2-3-1',theme:cfg.background?'custom':'brand',title:cfg.defaultTitle??'BENİM İLK 11’İM',lines:!cfg.background,numbers:true,display:'photo',view:'perspective',direction:'up',primary:cfg.primary||'#efbc35',secondary:cfg.secondary||'#b32031',players:Array(11).fill(null),points:positions(formations.includes(cfg.formation)?cfg.formation:'4-2-3-1','up')});
    let state=base(),selected=0,undo=[],redo=[],drag=null,bg=null,logo=null,footerLogo=null,suppressClickUntil=0,pendingPhoto='';
    const imageCache=new Map();
    const storageKey='pesindeyiz-ilk11-v1:'+location.pathname+':'+instance;
    try{
      const saved=JSON.parse(localStorage.getItem(storageKey));
      if(saved&&formations.includes(saved.formation)&&Array.isArray(saved.players)&&saved.players.length===11&&Array.isArray(saved.points)&&saved.points.length===11){
        state={...base(),...saved};state.points=saved.points.map(p=>({x:Math.max(.1,Math.min(.9,Number(p?.x)||.5)),y:Math.max(.25,Math.min(.85,Number(p?.y)||.5))}));
        state.players=saved.players.map((p,i)=>p&&typeof p.name==='string'?{id:String(p.id||''),name:p.name.slice(0,40),number:String(p.number||'').slice(0,2),position:String(p.position||''),preferredRole:tactics.roleNames[p.preferredRole]?p.preferredRole:tactics.templates[state.formation][i].role,photo:typeof p.photo==='string'&&/^data:image\/(png|jpeg|webp);base64,/.test(p.photo)?p.photo.slice(0,400000):'',transfer:!!p.transfer}:null);
        if(!['brand','green','blue','white','custom'].includes(state.theme)||state.theme==='custom'&&!cfg.background)state.theme='brand';
        state.title=String(state.title||'').slice(0,45);state.lines=!!state.lines;state.numbers=!!state.numbers;
        if(!['photo','shirt','circle'].includes(state.display))state.display='photo';if(!['perspective','flat'].includes(state.view))state.view='perspective';if(!['up','down'].includes(state.direction))state.direction='down';
        for(const k of ['primary','secondary'])if(!/^#[0-9a-f]{6}$/i.test(state[k]))state[k]=base()[k];
        if(saved.layoutVersion!==2){state.points=positions(state.formation,state.direction,state.view);state.layoutVersion=2;}
      }
    }catch(e){}
    if(state.direction!=='up'){state.points=state.points.map(p=>({...p,y:1.10-p.y}));state.direction='up';}
    // Refresh saved roster players after an administrator edits their name or number.
    function reconcilePlayers(){
      state.players=state.players.map(p=>{
      if(!p||p.transfer)return p;
      const current=roster.find(r=>r.id===p.id)||roster.find(r=>fold(r.name)===fold(p.name));
      if(current)return {...p,...current};
      // Remove managed players hidden or deleted by the administrator; keep custom targets.
      return /^(p[a-f0-9]{32}|custom-[a-f0-9]{32}|player-[a-f0-9]{32})$/.test(p.id)?null:p;
    });
    }
    reconcilePlayers();
    function status(msg){$('.pi11-status').textContent=msg;}
    function persist(){try{localStorage.setItem(storageKey,JSON.stringify(state));}catch(e){status('Tarayıcı kaydı kullanılamıyor. Kadronu PNG olarak indirebilirsin.');}}
    function checkpoint(){undo.push(clone(state));if(undo.length>40)undo.shift();redo=[];}
    function change(fn,msg=''){checkpoint();fn();sync();persist();if(msg)status(msg);}
    function select(i){selected=i;sync();}
    function assign(p){
      change(()=>{
        if(p&&!p.transfer){const previous=state.players.findIndex((v,i)=>i!==selected&&v&&fold(v.name)===fold(p.name));if(previous>=0){state.players[previous]=state.players[selected];if(state.players[previous])state.players[previous].preferredRole=tactics.templates[state.formation][previous].role;}}
        state.players[selected]=p?{...clone(p),preferredRole:tactics.templates[state.formation][selected].role}:null;
      },p?(p.transfer?'Bu konum için transfer işaretlendi.':p.name+' kadroya eklendi.'):'Konum boşaltıldı.');
      dialog.close();
    }
    function sync(){
      reconcilePlayers();
      const focusIndex=Array.from(slots.children).indexOf(document.activeElement);
      for(const key of ['formation','theme','title','lines','numbers','display','view','primary','secondary']){const el=$('[data-field="'+key+'"]');if(el.type==='checkbox')el.checked=state[key];else el.value=state[key];}
      const role=tactics.roleNames[tactics.templates[state.formation][selected].role];
      const p=state.players[selected];$('.pi11-current').textContent=role+' · '+(p?p.name:'Oyuncu seç');
      $('.pi11-formation-note').textContent=state.formation==='3-5-2-B'?'3-5-2 alternatif: tek ön libero, iki iç oyuncu ve kanat bekler.':state.formation==='4-1-2-1-2'?'Baklava: tek ön libero, iki iç oyuncu ve on numara.':'Mevkiler korunur; yeni düzene göre konumlar yenilenir.';
      $('.pi11-tactic-preview').innerHTML='<svg viewBox="0 0 180 120" role="img" aria-label="'+esc(state.formation)+'"><rect x="1" y="1" width="178" height="118" rx="10" fill="#65112a"/><path d="M15 8H165V112H15ZM15 60H165" fill="none" stroke="#ffffff55"/><circle cx="90" cy="60" r="15" fill="none" stroke="#ffffff55"/>'+positions(state.formation,state.direction,'flat').map(point=>'<circle cx="'+(point.x*180)+'" cy="'+((point.y-.20)/.72*120)+'" r="4.5" fill="#ffcd50"/>').join('')+'</svg>';
      $('[data-field="x"]').value=Math.round(state.points[selected].x*100);$('[data-field="y"]').value=Math.round(state.points[selected].y*100);
      $('[data-action="undo"]').disabled=!undo.length;$('[data-action="redo"]').disabled=!redo.length;
      slots.replaceChildren();state.points.forEach((point,i)=>{const b=document.createElement('button');b.className='pi11-slot';b.style.left=(point.x*100)+'%';b.style.top=(point.y*100)+'%';b.setAttribute('aria-label',(state.players[i]?state.players[i].name:'Boş konum '+(i+1))+', oyuncu seç');b.addEventListener('click',()=>{select(i);openDialog();});b.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();selected=i;change(()=>{const p=state.points[i];if(e.key==='ArrowLeft')p.x=Math.max(.1,p.x-.01);if(e.key==='ArrowRight')p.x=Math.min(.9,p.x+.01);if(e.key==='ArrowUp')p.y=Math.max(.25,p.y-.01);if(e.key==='ArrowDown')p.y=Math.min(.85,p.y+.01);});}});b.addEventListener('pointerdown',e=>startDrag(e,i));slots.append(b);});
      if(focusIndex>=0&&slots.children[focusIndex])slots.children[focusIndex].focus();
      draw(true);
    }
    function path(points,fill,stroke){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.stroke();}}
    function text(value,x,y,size,color,max=950,weight=700){ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=color;let s=size;ctx.font=weight+' '+s+'px Arial';while(ctx.measureText(value).width>max&&s>14){s--;ctx.font=weight+' '+s+'px Arial';}ctx.fillText(value,x,y);}
    function draw(editing){
      ctx.clearRect(0,0,1080,1080);
      const palette={brand:['#65112a','#180711','#a83043'],green:['#145531','#081c1c','#2a7f45'],blue:['#153d65','#071926','#266487'],white:['#ffffff','#e4e8ee','#cfd9e1']};
      const colors=palette[state.theme]||palette.brand;const light=state.theme==='white';
      const gradient=ctx.createLinearGradient(0,0,1080,1080);gradient.addColorStop(0,colors[0]);gradient.addColorStop(1,colors[1]);ctx.fillStyle=gradient;ctx.fillRect(0,0,1080,1080);
      if(state.theme==='custom'&&bg)ctx.drawImage(bg,0,0,1080,1080);
      const white=light?'#3b4855':'#ffffff';
      if(state.theme!=='custom'){
        ctx.fillStyle=light?'#b7212e':'#ffcd50';ctx.fillRect(60,58,8,62);
        if(logo){
          ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillStyle=white;ctx.font='800 26px Arial';
          ctx.fillText(cfg.brand||'PEŞİNDEYİZ',174,74,340);
        }else text(cfg.brand||'PEŞİNDEYİZ',logo?322:270,74,26,white,logo?330:380,800);
        text(state.title||'İLK 11 KUR!',540,143,54,white,920,900);
      }
      if(state.theme==='custom'&&state.title) {ctx.fillStyle='#18071199';ctx.fillRect(60,112,960,70);text(state.title,540,147,42,'#fff',900,900);}
      if(logo){fitImage(logo,86,42,76,76);}
      const project=(u,v)=>[(.5+(u-.5)*2*(state.view==='perspective'?.32+.115*v:.43))*1080,(.22+.66*v)*1080];
      if(state.lines){
        ctx.lineWidth=3;const line=light?'#71839388':'#ffffff60';
        const rect=(u1,v1,u2,v2,fill=null)=>path([project(u1,v1),project(u2,v1),project(u2,v2),project(u1,v2)],fill,line);
        if(state.view==='perspective'&&state.theme!=='custom')path([project(0,1),project(1,1),[project(1,1)[0]-14,978],[project(0,1)[0]+14,978]],'#170913',null);
        rect(0,0,1,1,state.theme==='custom'?null:colors[2]+'80');
        if(state.theme!=='custom')for(let v=0;v<1;v+=.2)path([project(0,v),project(1,v),project(1,v+.1),project(0,v+.1)],'#ffffff08',null);
        ctx.strokeStyle=line;ctx.beginPath();ctx.moveTo(...project(0,.5));ctx.lineTo(...project(1,.5));ctx.stroke();
        ctx.beginPath();ctx.ellipse(540,project(.5,.5)[1],103,state.view==='perspective'?62:80,0,0,Math.PI*2);ctx.stroke();
        rect(.28,0,.72,.16);rect(.38,0,.62,.065);rect(.28,.84,.72,1);rect(.38,.935,.62,1);
        ctx.fillStyle=line;for(const v of [.11,.5,.89]){ctx.beginPath();ctx.arc(...project(.5,v),4,0,Math.PI*2);ctx.fill();}
      }
      state.points.forEach((point,i)=>{
        const x=point.x*1080,y=point.y*1080,p=state.players[i];
        ctx.save();ctx.translate(x,y);
        if(editing&&i===selected){ctx.strokeStyle='#ffcd50';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,54,0,Math.PI*2);ctx.stroke();}
        if(!p){
          ctx.beginPath();ctx.arc(0,0,35,0,Math.PI*2);ctx.fillStyle='#110d19b8';ctx.fill();text('+',0,0,50,'#fff',65,400);
          const role=tactics.roleNames[tactics.templates[state.formation][i].role];text(role.toLocaleUpperCase('tr'),0,60,21,white,150,700);
        }else{
          const shirt=[[-17,-42],[-34,-34],[-47,-12],[-31,-4],[-24,-16],[-24,31],[24,31],[24,-16],[31,-4],[47,-12],[34,-34],[17,-42],[9,-34],[-9,-34]];
          const photo=state.display==='photo'&&!p.transfer?playerImage(p):null;
          if(p.transfer||state.display==='shirt'){
            ctx.lineWidth=2;path(shirt,p.transfer?'#f8f8f8':i===0?'#528f7f':state.primary,'#ffffffaa');
            if(!p.transfer){ctx.save();ctx.beginPath();shirt.forEach((t,j)=>j?ctx.lineTo(...t):ctx.moveTo(...t));ctx.closePath();ctx.clip();ctx.fillStyle=i===0?'#285c50':state.secondary;ctx.fillRect(0,-50,55,90);ctx.restore();}
            if(state.numbers&&!p.transfer&&p.number!=='')text(String(p.number),0,0,33,'#fff',55,900);
          }else{
            ctx.beginPath();ctx.arc(0,0,45,0,Math.PI*2);ctx.fillStyle=state.secondary;ctx.fill();ctx.strokeStyle=state.primary;ctx.lineWidth=4;ctx.stroke();
            if(photo){
              ctx.save();ctx.beginPath();ctx.arc(0,0,43,0,Math.PI*2);ctx.clip();ctx.fillStyle='#f3eee8';ctx.fillRect(-44,-44,88,88);const w=photo.naturalWidth||photo.width,h=photo.naturalHeight||photo.height;const scale=Math.max(86/w,86/h);ctx.drawImage(photo,-w*scale/2,-h*scale/2,w*scale,h*scale);ctx.restore();
            }else text(state.numbers&&p.number!==''?String(p.number):p.name.split(/\s+/).map(s=>s[0]).slice(0,2).join(''),0,0,34,'#fff',75,900);
            if(photo&&state.numbers&&p.number!==''){ctx.beginPath();ctx.arc(36,-29,19,0,Math.PI*2);ctx.fillStyle='#fff';ctx.fill();text(String(p.number),36,-29,22,'#6c1327',32,800);}
          }
          let label=p.transfer?'TRANSFER LAZIM':labels[p.name]||p.name.toLocaleUpperCase('tr');
          if(label.length>18){const bits=p.name.trim().split(/\s+/);label=bits.length>1?bits[0][0].toLocaleUpperCase('tr')+'. '+bits[bits.length-1].toLocaleUpperCase('tr'):label;}
          ctx.fillStyle=p.transfer?'#ffcd50':'#fff';ctx.fillRect(-76,52,152,37);text(label,0,71,27,p.transfer?'#371119':'#3d1320',141,800);
        }
        ctx.restore();
      });
      const used=state.players.filter(Boolean).length;
      text(state.formation,130,1020,25,white,190,800);
      if(footerLogo){if(light){ctx.fillStyle='#65112a';ctx.fillRect(308,1009,464,39);}fitImage(footerLogo,320,1017,440,24.5);}else text(cfg.brand||'PEŞİNDEYİZ',540,1020,27,white,420,800);
      text(used+'/11',968,1020,25,white,90,700);
    }
    function fitImage(img,x,y,w,h){
      const iw=img.naturalWidth||img.width,ih=img.naturalHeight||img.height;
      const scale=Math.min(w/iw,h/ih);ctx.drawImage(img,x+(w-iw*scale)/2,y+(h-ih*scale)/2,iw*scale,ih*scale);
    }
    function playerImage(p){
      const url=p.photo||photoURLs.get(fold(p.name));if(!url)return null;
      if(!imageCache.has(url)){
        const record={image:null,promise:null};imageCache.set(url,record);
        record.promise=new Promise(resolve=>{const img=new Image();const timeout=setTimeout(resolve,8000);img.crossOrigin='anonymous';img.onload=()=>{clearTimeout(timeout);record.image=img;resolve();draw(true);};img.onerror=()=>{clearTimeout(timeout);resolve();};img.src=url;});
      }
      return imageCache.get(url).image;
    }
    function list(){
      const q=fold($('.pi11-search').value),list=$('.pi11-player-list');list.replaceChildren();
      const found=roster.filter(p=>fold(p.name+' '+p.number).includes(q));
      found.forEach(p=>{const b=document.createElement('button');const already=state.players.some((v,i)=>i!==selected&&v&&fold(v.name)===fold(p.name));const photo=photoURLs.get(fold(p.name));b.innerHTML=(photo?'<img class="pi11-player-photo" src="'+esc(photo)+'" alt="" loading="lazy">':'<span class="pi11-player-photo pi11-photo-placeholder">'+esc(p.name[0])+'</span>')+'<span class="pi11-player-info">'+esc(p.name)+'<small>'+esc(p.position)+(already?' · Kadroda; seçersen yer değiştirir':'')+'</small></span><span class="pi11-player-number">'+esc(p.number||'—')+'</span>';b.addEventListener('click',()=>assign(p));list.append(b);});
      if(!found.length)list.textContent='Oyuncu bulunamadı. Aşağıdan özel oyuncu ekleyebilirsin.';
    }
    function openDialog(){
      $('.pi11-search').value='';$('.pi11-dialog-error').textContent='';const p=state.players[selected];pendingPhoto=p?.photo||'';$('.pi11-photo-file').value='';$('.pi11-photo-note').textContent=pendingPhoto?'Özel fotoğraf seçili.':'İsteğe bağlı; hazır oyuncuların fotoğrafı otomatik gelir.';$('.pi11-custom-name').value=p&&!p.transfer?p.name:'';$('.pi11-custom-number').value=p&&!p.transfer?p.number:'';list();dialog.showModal();$('.pi11-search').focus();
    }
    $('.pi11-search').addEventListener('input',list);$('.pi11-close').addEventListener('click',()=>dialog.close());
    $('.pi11-photo-file').addEventListener('change',()=>{
      const file=$('.pi11-photo-file').files[0];if(!file)return;
      if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>5*1024*1024){$('.pi11-dialog-error').textContent='En fazla 5 MB PNG, JPEG veya WebP seç.';$('.pi11-photo-file').value='';return;}
      const button=$('[data-choice="custom"]');button.disabled=true;$('.pi11-dialog-error').textContent='';
      const reader=new FileReader();reader.onerror=()=>{button.disabled=false;$('.pi11-dialog-error').textContent='Fotoğraf okunamadı.';};reader.onload=()=>{
        const img=new Image();img.onerror=()=>{button.disabled=false;$('.pi11-dialog-error').textContent='Fotoğraf açılamadı.';};img.onload=()=>{
          try{const temp=document.createElement('canvas');temp.width=200;temp.height=200;const c=temp.getContext('2d'),scale=Math.max(200/img.width,200/img.height);c.drawImage(img,(200-img.width*scale)/2,(200-img.height*scale)/2,img.width*scale,img.height*scale);pendingPhoto=temp.toDataURL('image/png');$('.pi11-photo-note').textContent='Özel fotoğraf hazır; oyuncuyu ekleyerek kaydet.';}
          catch(e){$('.pi11-dialog-error').textContent='Fotoğraf işlenemedi.';}finally{button.disabled=false;}
        };img.src=String(reader.result);
      };reader.readAsDataURL(file);
    });
    dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
    dialog.querySelectorAll('[data-choice]').forEach(b=>b.addEventListener('click',()=>{
      if(b.dataset.choice==='photo-clear'){pendingPhoto='';$('.pi11-photo-file').value='';$('.pi11-photo-note').textContent='Hazır oyuncu fotoğrafı kullanılacak.';return;}
      if(b.dataset.choice==='remove')return assign(null);
      if(b.dataset.choice==='transfer')return assign({id:'transfer-'+selected,name:'Transfer lazım',number:'',position:'Transfer ihtiyacı',transfer:true});
      const name=$('.pi11-custom-name').value.trim(),number=$('.pi11-custom-number').value;
      if(!name){$('.pi11-dialog-error').textContent='Oyuncu adını yaz.';return;}
      if(number!==''&&(!/^\d{1,2}$/.test(number)||Number(number)>99)){ $('.pi11-dialog-error').textContent='Forma numarası 0–99 arasında olmalı.';return; }
      const match=roster.find(p=>fold(p.name)===fold(name));
      assign({id:match?match.id:'custom-'+fold(name),name,number,position:match?match.position:'Özel oyuncu',photo:pendingPhoto,transfer:false});
    }));
    mount.querySelectorAll('[data-field]').forEach(el=>el.addEventListener('change',()=>{
      const f=el.dataset.field;change(()=>{
        if(f==='x'||f==='y'){state.points[selected][f]=Number(el.value)/100;return;}
        const prevFormation=state.formation,prevView=state.view,selectedName=state.players[selected]?.name;
        state[f]=el.type==='checkbox'?el.checked:el.value;
        if(f==='formation'){state.players=tactics.remap(state.players,prevFormation,state.formation);state.points=positions(state.formation,state.direction,state.view);selected=selectedName?Math.max(0,state.players.findIndex(p=>p?.name===selectedName)):0;}
        if(f==='view')state.points=state.points.map(p=>{const v=(p.y-.22)/.66;const oldHalf=prevView==='perspective'?.32+.115*v:.43;const newHalf=state.view==='perspective'?.32+.115*v:.43;return {...p,x:Math.max(.1,Math.min(.9,.5+(p.x-.5)*newHalf/oldHalf))};});
      },f==='formation'?'Formasyon değişti; oyuncular mevkilerine göre yerleştirildi.':'');
    }));
    mount.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',async()=>{
      const a=b.dataset.action;
      if(a==='edit')openDialog();
      if(a==='transfer')assign({id:'transfer-'+selected,name:'Transfer lazım',number:'',position:'Transfer ihtiyacı',transfer:true});
      if(a==='remove')assign(null);
      if(a==='align')change(()=>state.points=positions(state.formation,state.direction,state.view),'Konumlar formasyona hizalandı.');
      if(a==='clear')change(()=>{state.players=Array(11).fill(null);state.points=positions(state.formation,state.direction,state.view);},'Kadro temizlendi. Geri al ile dönebilirsin.');
      if(a==='undo'&&undo.length){redo.push(clone(state));state=undo.pop();sync();persist();}
      if(a==='redo'&&redo.length){undo.push(clone(state));state=redo.pop();sync();persist();}
      if(a==='reset-colors')change(()=>{state.primary=base().primary;state.secondary=base().secondary;},'Renkler varsayılana döndürüldü.');
      if(a==='restart')change(()=>{state=base();selected=0;},'Baştan başladın. Geri al ile önceki kadrona dönebilirsin.');
      if(a.startsWith('share-')){
        b.disabled=true;status('Paylaşım hazırlanıyor…');try{await share(a.slice(6));}catch(e){status('Paylaşım görseli hazırlanamadı. Medya görsellerini kontrol et.');}finally{b.disabled=false;}
      }
      if(a==='download'){
        b.disabled=true;
        try{const blob=await pngBlob();if(window.PI11Native)await window.PI11Native.savePNG(blob);else saveBlob(blob);status(window.PI11Native?'Kadro galeriye kaydedildi.':'1080 × 1080 PNG hazır.');}
        catch(e){status(window.PI11Native?'Galeriye kaydedilemedi. Fotoğraf ekleme iznini kontrol edip tekrar dene.':'Görsel indirilemedi. Medya görsellerini kontrol et.');}
        finally{draw(true);b.disabled=false;}
      }
    }));
    async function pngBlob(){
      await Promise.all(brandLoads);
      if(state.display==='photo'){state.players.filter(Boolean).forEach(playerImage);await Promise.all(Array.from(imageCache.values()).map(r=>r.promise));}
      draw(false);
      try{return await new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('export')),'image/png'));}
      finally{draw(true);}
    }
    function saveBlob(blob){
      const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='pesindeyiz-ilk11.png';
      document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
    }
    function shareText(){
      return (state.title||'Benim ilk 11’im')+' · '+state.formation+' #Galatasaray #Peşindeyiz'+'\n\n'+(cfg.siteUrl||location.origin+location.pathname);
    }
    async function share(platform){
      if(window.PI11Native){
        try{await window.PI11Native.sharePNG(await pngBlob(),shareText(),state.title||'İlk 11');status('Paylaşım ekranı açıldı.');}
        catch(e){status(e.name==='AbortError'?'Paylaşım iptal edildi.':'Paylaşım açılamadı. Yeniden deneyebilirsin.');}
        return;
      }
      const ready=(!cfg.logo||logo)&&(!cfg.footerLogo||footerLogo)&&(!(state.theme==='custom'&&cfg.background)||bg)&&
        (state.display!=='photo'||state.players.filter(p=>p&&!p.transfer).every(p=>{const url=p.photo||photoURLs.get(fold(p.name));return !url||imageCache.get(url)?.image;}));
      if(ready&&navigator.share&&navigator.canShare){
        let file;
        try{
          draw(false);const encoded=canvas.toDataURL('image/png').split(',')[1],binary=atob(encoded),bytes=new Uint8Array(binary.length);
          for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
          file=new File([bytes],'pesindeyiz-ilk11.png',{type:'image/png'});
        }catch(e){}finally{draw(true);}
        let supported=false;try{supported=!!(file&&navigator.canShare({files:[file]}));}catch(e){}
        if(supported){
          try{await navigator.share({files:[file],title:state.title||'İlk 11',text:shareText()});status('Kadro ve paylaşım metni cihazın paylaşım uygulamasına aktarıldı.');return;}
          catch(e){if(e.name==='AbortError'){status('Paylaşım iptal edildi.');return;}}
        }
      }
      await sharePreview(platform);status('Paylaşım görseli hazır.');
    }
    async function sharePreview(platform){
      const blob=await pngBlob(),url=URL.createObjectURL(blob),file=new File([blob],'pesindeyiz-ilk11.png',{type:'image/png'});
      const name={x:'X',instagram:'Instagram',whatsapp:'WhatsApp'}[platform];
      const text=shareText();
      let native=false;try{native=!!(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]}));}catch(e){}
      const d=document.createElement('dialog');d.className='pi11-share-dialog';d.setAttribute('aria-label',name+' paylaşımı');
      d.innerHTML='<h3>'+({x:'X’te',instagram:'Instagram’da',whatsapp:'WhatsApp’ta'}[platform])+' paylaş</h3><img class="pi11-share-preview" alt="Paylaşılacak kadro görseli"><p>'+ (native?'Görseli paylaş düğmesine bas; açılan cihaz menüsünden '+name+' uygulamasını seç.':'Görseli indir ve '+name+' uygulamasında paylaşımına ekle.')+'</p><div class="pi11-actions">'+(native?'<button class="pi11-primary" data-share-native>Görseli paylaş</button>':'')+'<button data-share-download>Görseli indir</button><button data-share-close>Kapat</button></div><p class="pi11-share-result" role="status"></p>';
      d.querySelector('img').src=url;
      const caption=document.createElement('label');caption.className='pi11-share-caption';caption.textContent='Paylaşım yazısı';
      const captionInput=document.createElement('textarea');captionInput.value=text;captionInput.rows=4;caption.append(captionInput);d.querySelector('.pi11-actions').before(caption);
      const link=document.createElement('a');link.target='_blank';link.rel='noopener noreferrer';
      if(platform==='x'){link.href='https://twitter.com/intent/tweet?text='+encodeURIComponent(text);link.textContent='X’te metin ve bağlantıyı aç';}
      else if(platform==='whatsapp'){link.href='https://wa.me/?text='+encodeURIComponent(text);link.textContent='WhatsApp’ta metin ve bağlantıyı aç';}
      else {link.href='https://www.instagram.com/';link.textContent='Instagram’ı aç';}
      captionInput.addEventListener('input',()=>{if(platform==='x')link.href='https://twitter.com/intent/tweet?text='+encodeURIComponent(captionInput.value);else if(platform==='whatsapp')link.href='https://wa.me/?text='+encodeURIComponent(captionInput.value);});
      d.append(link);mount.append(d);
      const close=()=>{d.close();d.remove();URL.revokeObjectURL(url);};
      d.querySelector('[data-share-close]').addEventListener('click',close);
      d.addEventListener('cancel',e=>{e.preventDefault();close();});
      d.querySelector('[data-share-download]').addEventListener('click',()=>saveBlob(blob));
      const nativeButton=d.querySelector('[data-share-native]');
      if(nativeButton)nativeButton.addEventListener('click',async()=>{
        nativeButton.disabled=true;
        try{await navigator.share({files:[file],title:state.title||'İlk 11',text:captionInput.value});d.querySelector('.pi11-share-result').textContent='Görsel cihazın paylaşım uygulamasına aktarıldı.';}
        catch(e){d.querySelector('.pi11-share-result').textContent=e.name==='AbortError'?'Paylaşım iptal edildi.':'Paylaşım ekranı açılamadı. Görseli indirip uygulamada paylaşabilirsin.';}
        finally{nativeButton.disabled=false;}
      });
      d.showModal();d.querySelector('button').focus();
    }
    function startDrag(e,i){
      if(e.button!==0)return;selected=i;const rect=canvas.getBoundingClientRect();drag={i,startX:e.clientX,startY:e.clientY,rect,before:clone(state),moved:false,target:e.currentTarget};e.currentTarget.setPointerCapture(e.pointerId);
    }
    mount.addEventListener('pointermove',e=>{
      if(!drag)return;const d=drag;if(!d.moved&&Math.hypot(e.clientX-d.startX,e.clientY-d.startY)<7)return;d.moved=true;
      state.points[d.i]={x:Math.max(.1,Math.min(.9,(e.clientX-d.rect.left)/d.rect.width)),y:Math.max(.25,Math.min(.85,(e.clientY-d.rect.top)/d.rect.height))};
      d.target.style.left=state.points[d.i].x*100+'%';d.target.style.top=state.points[d.i].y*100+'%';draw(true);
    });
    mount.addEventListener('pointerup',e=>{
      if(!drag)return;const d=drag;drag=null;if(d.moved){undo.push(d.before);if(undo.length>40)undo.shift();redo=[];e.preventDefault();suppressClickUntil=Date.now()+300;persist();sync();status('Oyuncunun konumu güncellendi.');}
    });
    mount.addEventListener('click',e=>{if(Date.now()<suppressClickUntil){e.preventDefault();e.stopImmediatePropagation();}},{capture:true});
    mount.addEventListener('pointercancel',()=>{if(drag){state=drag.before;drag=null;sync();}});
    const brandLoads=[];
    function loadImage(url,key){
      if(!url)return;
      brandLoads.push(new Promise(resolve=>{
        const img=new Image();const timer=setTimeout(resolve,8000);img.crossOrigin='anonymous';
        img.onload=()=>{clearTimeout(timer);if(key==='background')bg=img;else if(key==='footer')footerLogo=img;else logo=img;draw(true);resolve();};
        img.onerror=()=>{clearTimeout(timer);status((key==='background'?'Arka plan':'Logo')+' yüklenemedi. WordPress medya ayarını kontrol edin.');resolve();};
        img.src=url;
      }));
    }
    root.pi11UpdateConfig=next=>{
      const previous=base();cfg=clone(next);
      const combined=[...(cfg.roster||[]),...(cfg.extraPlayers||[]).filter(p=>!(cfg.roster||[]).some(r=>fold(r.name)===fold(p.name)))];
      roster.splice(0,roster.length,...combined);photoURLs.clear();for(const [name,url] of Object.entries(cfg.photos||{}))photoURLs.set(fold(name),url);
      const defaults=base();
      for(const key of ['primary','secondary','title','theme','lines'])if(state[key]===previous[key])state[key]=defaults[key];
      if(state.formation===previous.formation&&state.formation!==defaults.formation){state.players=tactics.remap(state.players,state.formation,defaults.formation);state.formation=defaults.formation;state.points=positions(state.formation,state.direction,state.view);}
      const theme=$('[data-field="theme"]');let option=theme.querySelector('[value="custom"]');
      if(cfg.background&&!option){option=document.createElement('option');option.value='custom';option.textContent='Canva arka planımız';theme.append(option);}
      if(!cfg.background&&option){option.remove();if(state.theme==='custom')state.theme='brand';}
      if(dialog.open)list();
      bg=null;logo=null;footerLogo=null;sync();persist();
      loadImage(cfg.background,'background');loadImage(cfg.logo,'logo');loadImage(cfg.footerLogo,'footer');
    };
    sync();persist();loadImage(cfg.background,'background');loadImage(cfg.logo,'logo');loadImage(cfg.footerLogo,'footer');
  });
})();
